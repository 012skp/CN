#to build it enter
$ make
